package com.example.midtest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button btnkubus, btnbalok,btnbola;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnkubus = (Button) findViewById(R.id.btnkubus);
        btnbalok = (Button)findViewById(R.id.btnbalok);
        btnbola = (Button) findViewById(R.id.btnbola);



       btnkubus.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intetkubus  = new Intent(MainActivity.this ,Inputkubus.class);
               startActivity(intetkubus);
           }
       });

       btnbalok.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intentbalok = new Intent(MainActivity.this, imputBalok.class);
               startActivity(intentbalok);
           }
       });

       btnbola.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intentbola = new Intent(MainActivity.this, inputBola.class);
               startActivity(intentbola);
           }
       });

    }


}
