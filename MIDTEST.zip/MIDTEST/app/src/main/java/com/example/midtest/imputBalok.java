package com.example.midtest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class imputBalok extends AppCompatActivity {

    EditText panjang,tinggi,lebar;
    Button btnhitung;
    Double n1,n2,n3,hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imput_balok);

        panjang = (EditText) findViewById(R.id.panjang1);
        tinggi= (EditText) findViewById(R.id.tinggi1);
        lebar = (EditText) findViewById(R.id.lebar11);
        btnhitung =  (Button) findViewById(R.id.hitung);

        btnhitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1 = Double.parseDouble((panjang.getText().toString()));
                n2 = Double.parseDouble((lebar.getText().toString()));
                n3 = Double.parseDouble((tinggi.getText().toString()));
                hasil  = n1 * n2 * n3;

                Intent intent1 = new Intent(imputBalok.this, hasilform.class);
                intent1.putExtra("data1", hasil);

                startActivity(intent1);
            }
        });


    }
}
