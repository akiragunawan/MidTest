package com.example.midtest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class inputBola extends AppCompatActivity {


    EditText jari1,jari2,jari3;
    Button htgg;
    Double n1,n2,n3,hsl;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_bola);

        jari1 = (EditText) findViewById(R.id.r1);

        htgg =  (Button) findViewById(R.id.htg);

        htgg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                n1 = Double.parseDouble((jari1.getText().toString()));

                hsl  = 4 * 3.14 * n1 * n1*n1 / 3;

                Intent intent1 = new Intent(inputBola.this, hasilform.class);
                intent1.putExtra("data1", hsl);

                startActivity(intent1);

            }
        });

    }
}
