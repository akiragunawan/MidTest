package com.example.midtest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Inputkubus extends AppCompatActivity {

    EditText sisi11;
    Button htgkubus;
    Double n1,n2,n3,hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inputkubus);

        sisi11 = (EditText) findViewById(R.id.sisi1);
        htgkubus =  (Button) findViewById(R.id.btnhitung1);


        htgkubus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1 = Double.parseDouble((sisi11.getText().toString()));

                hasil  = n1 * n1 * n1;

                Intent intent1 = new Intent(Inputkubus.this, hasilform.class);
                intent1.putExtra("data1", hasil);

                startActivity(intent1);
            }
        });

    }
}
